#crear usurio y contrasena para dar acceso
#los dos usurios y contrasenas deben funcionar
import secrets
print ("SISTEMA DE SEGURIDAD")
nombre = input ("Ingrese nombre: ")

#variables

password = input ("Ingrese una contrasena: ")
if password == secrets.contrasenia1 and nombre == secrets.nombre1:
    print ("Acceso correcto")
elif password == secrets.contrasena2 and nombre == secrets.nombre2:
    print("Acceso Correcto")
else:
    print("Acceso denegado")

