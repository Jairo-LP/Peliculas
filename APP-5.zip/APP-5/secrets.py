contrasenia1 = "12345"
nombre1 = "jairo"
nombre2 = "fernando"
contrasena2 = "123456"